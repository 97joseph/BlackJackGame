# Blackjack Simulator
 
## How to install and run (Windows operating systems):

- Download all files from this repository and extract them into a folder on your computer so that they are not zipped or compressed
- Open command prompt
- Change directory to the folder you just created (command to change directory is "**cd *folderpath***"
- run the command "**java Blackjack.java**" to start the program
- Follow the prompts to enter which values you would like to simulate for

## To view the results in Excel

After running a succesful simulation, the final bank values of every run will be saved into the "**output.csv**" file within the same folder, this file will contain one sim per row, with each column stepping back 1 game starting from the final result
